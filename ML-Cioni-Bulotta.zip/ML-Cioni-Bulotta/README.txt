###########################
## TEAM: PIS-AI
##  Federico Cioni [580718]
##  Davide Bulota [596782]
##  Project: Type B
###########################

In each specific folder there is the requirements.txt file
Contains the packages used to conduct tests on each software tools

The CUP results are located in the RESULT_CUP folder

The most extensive grid searches were performed with Pytorch
Read the README.txt in the Pytorch folder for more info