#main file used for building and training the NN with SCIKIT
#in this file we implemented grid search, CV, plots and score 
from sklearn.neural_network import MLPRegressor
import time
from itertools import product

from utils import importDatasetCup
from validation_functions import Kfold, split_folds, train_test_split
from sklearn.metrics import mean_squared_error

PATH = '../CUP/ML-CUP23-TR.csv'
K_FOLDS = 4
SEED = int(time.time()%150)

start_time = time.time()
dataset = importDatasetCup(PATH)

#we are going to do CV on training set, holding out a portion for model assessment
#seed = 42 example of "unlucky" fold
training_set, test_set = train_test_split(dataset=dataset,test_ratio=0.2, seed=SEED)

train, val = Kfold(dataset=training_set, k_fold=K_FOLDS)
#for lr,momentum in product(learning_rates,momentums):

#take the k lists containing the k folds splitted into x and y. Each of the value returned is a list
x_train,x_test,y_train,y_test = split_folds(val,train)

#HYPERPARAMETERS

# 20,20,40
# 40,40,80
# 80,80,160
# 160,160,256
# 50,100,80
# 40,80,100,80
# 64,128,200,128
# 40,40,80,100,100
#n_hunits = [[32,16,8],[64,32,16],[20,10,10],[100,50,25],[100,50]]
#n_hunits = [[32,64,128,256,256]]
n_hunits = [[512,512,600]]
#n_hunits = [[100,50],[128,64],[100,50,25]]
l_rates = [0.001]
lambdas = [0.0001]
momentums = [0.9]
batch = 64#len(train[0])
path_plot = '../cup_plots_scikit/'
for unit,lr,lambd,momentum in product(n_hunits,l_rates,lambdas,momentums):

    for i in range(K_FOLDS):

        mlp_regressor = MLPRegressor(hidden_layer_sizes=unit,
                                tol=0.00000001,
                                solver="sgd",
                                batch_size=batch, 
                                activation="tanh",
                                max_iter=5000,
                                learning_rate="constant",
                                learning_rate_init=lr,
                                momentum=momentum,
                                alpha=lambd,
                                random_state=SEED,
                                verbose=True,
                                n_iter_no_change=5000
                                )
        
        mlp_regressor.fit(x_train[i],y_train[i])
        predictions = mlp_regressor.predict(x_test[i])

        # Valutazione delle prestazioni
        mse = mean_squared_error(y_test[i], predictions)

        print(mse)