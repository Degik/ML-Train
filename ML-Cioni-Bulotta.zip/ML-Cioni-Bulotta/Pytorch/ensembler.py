import torch
import time
import numpy as np
import pandas as pd

from utils import importDatasetCup,importDatasetCupInput,importDatasetCupOutput
from validationFunctions import Kfold, split_folds, train_test_split

PATH = 'CUP/ML-CUP23-TEST-INPUT.csv'
K_FOLDS = 4
SEED = int(time.time()%150)

start_time = time.time()

x = importDatasetCupInput(file_name=PATH, blind=True)
x = torch.tensor(x.to_numpy())
x = x.float()

models = []

for i in range(6):
    models.append(torch.load(f'MODELS/model{str(i+1)}.pth', map_location=torch.device('cpu')))

pred = []

for i in range(6):
    models[i].eval()
    with torch.no_grad():
        outputs = models[i](x)
        pred.append(outputs)

for i in range(6):
    nmp = pred[i].numpy()
    df = pd.DataFrame(nmp) #convert to a dataframe
    df.to_csv(f'out mod{i+1}.csv',index=True) #save to file

all = []

for i in range(6):
    npm = pred[i].numpy()
    all.append(npm)

mean_all = np.mean(all, axis=0)
df = pd.DataFrame(mean_all)
df.to_csv("OUTPUT.csv", index=True)